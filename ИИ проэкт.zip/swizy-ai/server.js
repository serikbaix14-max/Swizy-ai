/* Мини-сервер без зависимостей: статика + прокси /api/chat к OpenAI-совместимому API.
   Запуск: node server.js   (Node.js 18+)
   Переменные окружения: PORT, AI_API_KEY, AI_BASE_URL (по умолчанию https://api.openai.com/v1), AI_MODEL */
const http = require('http'), fs = require('fs'), path = require('path');
const PORT = process.env.PORT || 3000, ROOT = __dirname;
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml', '.json': 'application/json' };
const ALLOWED = /^\/(index\.html|(css|js|assets)\/[\w.\-]+)$/; // server.js, .env и прочее не отдаются

async function chat(req, res) {
  const key = process.env.AI_API_KEY;
  if (!key) { res.writeHead(501, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify({ error: 'AI_API_KEY не задан. См. README.md' })); }
  let body = ''; for await (const c of req) { body += c; if (body.length > 1e6) { res.writeHead(413); return res.end(); } }
  try {
    const { messages, temperature } = JSON.parse(body);
    const up = await fetch((process.env.AI_BASE_URL || 'https://api.openai.com/v1') + '/chat/completions', {
      method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + key },
      body: JSON.stringify({ model: process.env.AI_MODEL || 'gpt-4o-mini', messages, temperature, stream: true })
    });
    if (!up.ok) { res.writeHead(up.status); return res.end(await up.text()); }
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache' });
    for await (const chunk of up.body) res.write(chunk);
    res.end();
  } catch (e) { if (!res.headersSent) res.writeHead(500); res.end(String(e.message)); }
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://localhost');
  if (url.pathname === '/api/chat' && req.method === 'POST') return chat(req, res);
  let p = url.pathname === '/' ? '/index.html' : url.pathname;
  if (!ALLOWED.test(p)) { res.writeHead(404); return res.end('Not found'); }
  fs.readFile(path.join(ROOT, p), (err, data) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(p)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(data);
  });
});
if (require.main === module) server.listen(PORT, () => console.log(`SWIZY AI: http://localhost:${PORT}`));
module.exports = server;
