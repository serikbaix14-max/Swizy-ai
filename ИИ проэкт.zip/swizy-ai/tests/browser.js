/* Браузерный тест (нужен Playwright): npm i -D playwright && npx playwright install chromium && node tests/browser.js */
const { chromium } = require('playwright');
const server = require('../server.js');
(async () => {
  await new Promise(r => server.listen(0, r)); const base = 'http://localhost:' + server.address().port;
  const b = await chromium.launch(); const errs = []; let ok = 0;
  const chk = (c, m) => { console.log(c ? '  ✓' : '  ✗', m); if (c) ok++; else process.exitCode = 1; };
  for (const [name, vp] of [['desktop', { width: 1280, height: 800 }], ['tablet', { width: 820, height: 1100 }], ['phone', { width: 390, height: 844 }]]) {
    console.log(name);
    const ctx = await b.newContext({ viewport: vp, colorScheme: 'light' }); const p = await ctx.newPage();
    p.on('pageerror', e => errs.push(name + ': ' + e.message)); p.on('console', m => m.type() === 'error' && errs.push(name + ': ' + m.text()));
    await p.goto(base); await p.waitForSelector('#sendBtn');
    chk(await p.evaluate(() => document.documentElement.dataset.theme) === 'default', 'старт: тема Default');
    // отправка сообщения
    await p.fill('#input', 'Привет!'); await p.press('#input', 'Enter');
    await p.waitForSelector('.msg.ai .actions button', { timeout: 8000 });
    chk((await p.textContent('.msg.ai .md')).includes('SWIZY'), 'ответ ИИ получен');
    // открыть оформление
    await p.evaluate(() => Swizy.app.openModal('appearance'));
    chk(await p.locator('.theme-card').count() === 10, '10 карточек тем');
    // просмотр
    await p.locator('.theme-card').nth(1).locator('[data-a=p]').click();
    chk(await p.evaluate(() => document.documentElement.dataset.theme) === 'sakura', 'просмотр Sakura');
    chk(await p.locator('#previewBar').isVisible() && !(await p.locator('.modal').isVisible()), 'панель предпросмотра, модалка скрыта');
    const bg1 = await p.evaluate(() => getComputedStyle(document.body).backgroundColor);
    await p.click('#previewCancel');
    chk(await p.evaluate(() => document.documentElement.dataset.theme) === 'default' && await p.evaluate(() => (localStorage['swizy.theme.v1'] ? JSON.parse(localStorage['swizy.theme.v1']).theme : 'default')) === 'default', 'отмена предпросмотра: тема не сохранена');
    // применение каждой темы, проверка изменения элементов
    const seen = new Set();
    for (let i = 0; i < 10; i++) {
      const ab = p.locator('.theme-card').nth(i).locator('[data-a=a]'); if (await ab.isEnabled()) await ab.click(); await p.waitForTimeout(80);
      const s = await p.evaluate(() => { const q = (s, pr) => getComputedStyle(document.querySelector(s))[pr];
        return [q('body', 'backgroundColor'), q('.sidebar', 'backgroundColor'), q('.composer', 'backgroundColor'), q('.msg.user .bubble', 'backgroundImage'), q('.btn.primary', 'backgroundImage'), q('.modal', 'backgroundColor')].join('|'); });
      seen.add(s);
    }
    chk(seen.size >= 9, `темы меняют фон/сайдбар/ввод/сообщения/кнопки/меню (${seen.size} уникальных наборов)`);
    // сохранение после перезагрузки
    await p.locator('.theme-card').nth(5).locator('[data-a=a]').click(); await p.waitForTimeout(700);
    await p.reload(); await p.waitForSelector('#sendBtn');
    chk(await p.evaluate(() => document.documentElement.dataset.theme) === 'ocean', 'тема сохранилась после перезагрузки');
    chk(await p.locator('.msg.user').count() === 1, 'история чата сохранилась');
    // режим
    await p.evaluate(() => Swizy.app.openModal('appearance')); await p.click('#modeSeg [data-m=dark]');
    chk(await p.evaluate(() => document.documentElement.dataset.mode) === 'dark', 'тёмный режим Ocean');
    await p.click('#modeSeg [data-m=light]');
    chk(await p.evaluate(() => document.documentElement.dataset.mode) === 'light', 'светлый режим Ocean');
    // горизонтальный скролл
    chk(await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1), 'нет горизонтального скролла');
    await p.screenshot({ path: `./shot-${name}.png` });
    await ctx.close();
  }
  // мобильный сайдбар
  const ctx = await b.newContext({ viewport: { width: 390, height: 844 } }); const p = await ctx.newPage(); await p.goto(base);
  const vis = () => p.evaluate(() => document.querySelector('#sidebar').getBoundingClientRect().right > 50);
  chk(!(await vis()), 'телефон: сайдбар скрыт'); await p.click('#menuBtn'); await p.waitForTimeout(400); chk(await vis(), 'телефон: сайдбар открывается');
  await b.close(); server.close();
  console.log(errs.length ? 'ОШИБКИ КОНСОЛИ:\n' + errs.join('\n') : 'Ошибок консоли нет'); if (errs.length) process.exitCode = 1;
})();
