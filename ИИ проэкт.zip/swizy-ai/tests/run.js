/* Тесты без зависимостей: node tests/run.js */
const fs = require('fs'), path = require('path'), vm = require('vm');
const root = path.join(__dirname, '..'), rd = f => fs.readFileSync(path.join(root, f), 'utf8');
let pass = 0, fail = 0;
const t = async (name, fn) => { try { await fn(); pass++; console.log('  ✓', name); } catch (e) { fail++; console.log('  ✗', name, '\n     ', e.message); } };
const ok = (c, m) => { if (!c) throw new Error(m || 'assertion failed'); };

(async () => {
  const { Store } = require('../js/storage.js');
  let { Theme, THEMES } = require('../js/themes.js');
  const { md } = require('../js/md.js');
  const { AI } = require('../js/ai.js');

  console.log('Themes');
  await t('10 тем в нужном порядке', () => ok(THEMES.map(x => x.id).join() === 'default,sakura,bubblegum,cyberpunk,vanilla,ocean,midnight,lavender,forest,sunset'));
  await t('все токены заданы и валидны', () => THEMES.forEach(th => ok(th.name && th.emoji && th.desc, th.id) || Object.entries(th.modes).forEach(([m, v]) =>
    ['bg', 'side', 'surface', 'text', 'muted', 'accent', 'accent2'].forEach(k => ok(/^#[0-9a-f]{6}$/i.test(v[k]), `${th.id}/${m}/${k}`)))));
  await t('контраст: текст ≥ 4.5, приглушённый ≥ 3, текст на кнопках ≥ 3', () => THEMES.forEach(th => Object.entries(th.modes).forEach(([m, v]) => {
    const id = `${th.id}/${m}`, on = Theme.pickOn(v.accent, v.accent2);
    ok(Theme.contrast(v.text, v.bg) >= 4.5, id + ' text/bg ' + Theme.contrast(v.text, v.bg).toFixed(2));
    ok(Theme.contrast(v.text, v.surface) >= 4.5, id + ' text/surface');
    ok(Theme.contrast(v.muted, v.bg) >= 3, id + ' muted/bg ' + Theme.contrast(v.muted, v.bg).toFixed(2));
    ok(Theme.contrast(v.muted, v.surface) >= 3, id + ' muted/surface ' + Theme.contrast(v.muted, v.surface).toFixed(2));
    ok(Theme.contrast(on, v.accent) >= 3 && Theme.contrast(on, v.accent2) >= 3, id + ' on/accent ' + Math.min(Theme.contrast(on, v.accent), Theme.contrast(on, v.accent2)).toFixed(2));
  })));
  await t('buildCSS: правило на каждый режим каждой темы', () => {
    const css = Theme.buildCSS(), n = THEMES.reduce((a, x) => a + Theme.modes(x).length, 0);
    ok((css.match(/\[data-theme=/g) || []).length === n, 'count');
  });
  await t('resolve режима', () => {
    const [def, sak] = [Theme.find('default'), Theme.find('sakura')];
    ok(Theme.resolve(def, 'light', false) === 'dark', 'dark-only');
    ok(Theme.resolve(sak, 'auto', true) === 'dark' && Theme.resolve(sak, 'auto', false) === 'light' && Theme.resolve(sak, 'light', true) === 'light');
  });
  await t('сохранение и восстановление после «перезагрузки»', () => {
    Theme.apply('ocean'); Theme.setPref('dark');
    delete require.cache[require.resolve('../js/themes.js')];
    const fresh = require('../js/themes.js').Theme; fresh.init();
    ok(fresh.state.theme === 'ocean' && fresh.state.pref === 'dark', JSON.stringify(fresh.state));
  });
  await t('неизвестная тема игнорируется', () => { Theme.apply('nope'); ok(Theme.state.theme !== 'nope'); });
  await t('предпросмотр не сохраняется, отмена возвращает тему', () => {
    Theme.apply('forest'); Theme.preview('sunset'); ok(Theme.previewing() === 'sunset' && Store.get(Theme.KEY).theme === 'forest');
    Theme.endPreview(false); ok(!Theme.previewing() && Theme.state.theme === 'forest');
    Theme.preview('sunset'); Theme.endPreview(true); ok(Store.get(Theme.KEY).theme === 'sunset');
  });

  console.log('Markdown');
  await t('экранирует HTML/XSS', () => { const h = md('<img src=x onerror=alert(1)> **b**'); ok(!h.includes('<img') && h.includes('<strong>b</strong>')); });
  await t('блоки кода и списки', () => { const h = md('- a\n- b\n\n```js\n<x>\n```'); ok(h.includes('<ul><li>a</li><li>b</li></ul>') && h.includes('&lt;x&gt;') && h.includes('data-copy')); });
  await t('незакрытый блок кода при стриминге не ломает вывод', () => ok(md('текст\n```js\nlet a').includes('<pre>')));
  await t('ссылки не выходят из атрибута', () => ok(!md('http://a.com/"onmouseover="x').includes('onmouseover="x')));

  console.log('AI');
  await t('mock-провайдер стримит ответ', async () => { let s = ''; await AI.stream({ messages: [{ role: 'user', content: 'Привет' }], settings: { provider: 'mock' }, onToken: x => s += x }); ok(s.includes('SWIZY')); });
  await t('mock-провайдер прерывается', async () => {
    const c = new AbortController(); setTimeout(() => c.abort(), 60); let err;
    try { await AI.stream({ messages: [{ role: 'user', content: 'x' }], settings: { provider: 'mock' }, signal: c.signal, onToken() { } }); } catch (e) { err = e; }
    ok(err && err.name === 'AbortError');
  });
  await t('register() подключает свой провайдер', async () => { AI.register('x', { async stream({ onToken }) { onToken('ok'); } }); let s = ''; await AI.stream({ messages: [], settings: { provider: 'x' }, onToken: v => s += v }); ok(s === 'ok'); });

  console.log('Проект (статический анализ)');
  const html = rd('index.html');
  await t('все файлы из index.html существуют', () => [...html.matchAll(/(?:src|href)="((?:css|js|assets)\/[^"]+)"/g)].forEach(m => ok(fs.existsSync(path.join(root, m[1])), m[1])));
  await t('нет дублей id', () => { const ids = [...html.matchAll(/\sid="([^"]+)"/g)].map(m => m[1]); ok(new Set(ids).size === ids.length, 'dup id'); });
  await t('все #id из app.js есть в HTML', () => [...rd('js/app.js').matchAll(/\$\('#([\w-]+)'\)/g)].forEach(m => ok(html.includes(`id="${m[1]}"`), m[1])));
  await t('все JS-файлы синтаксически корректны', () => fs.readdirSync(path.join(root, 'js')).forEach(f => new vm.Script(rd('js/' + f), { filename: f })));
  await t('все CSS-переменные определены', () => {
    const css = rd('css/base.css') + rd('css/components.css'), def = new Set([...css.matchAll(/(--[\w-]+)\s*:/g)].map(m => m[1]));
    ['bg', 'side', 'surface', 'text', 'muted', 'accent', 'accent2', 'on', 'glow', 'gloss'].forEach(k => def.add('--' + k));
    [...css.matchAll(/var\((--[\w-]+)(?:,[^)]*)?\)/g)].forEach(m => ok(def.has(m[1]) || m[1] === '--fs', 'не определена ' + m[1]));
  });
  await t('в CSS нет цветов, привязанных к конкретной теме', () => ok(!/\[data-theme=/.test(rd('css/components.css')) && !/\[data-theme=/.test(rd('css/base.css').replace(/\/\*[\s\S]*?\*\//g, '').replace(':root,[data-theme]', ''))));
  await t('адаптивные брейкпоинты присутствуют', () => ok(/max-width:899px/.test(rd('css/components.css')) && /max-width:700px/.test(rd('css/components.css')) && /viewport-fit=cover/.test(html)));

  console.log('Сервер');
  const server = require('../server.js');
  await new Promise(r => server.listen(0, r)); const base = 'http://localhost:' + server.address().port;
  await t('GET / отдаёт index.html', async () => ok((await (await fetch(base + '/')).text()).includes('SWIZY AI')));
  await t('server.js и package.json не отдаются', async () => ok((await fetch(base + '/server.js')).status === 404 && (await fetch(base + '/package.json')).status === 404 && (await fetch(base + '/js/../server.js')).status === 404));
  await t('/api/chat без ключа → 501', async () => { delete process.env.AI_API_KEY; ok((await fetch(base + '/api/chat', { method: 'POST', body: '{}' })).status === 501); });
  server.close();

  console.log(`\nИтого: ${pass} успешно, ${fail} с ошибками`); process.exit(fail ? 1 : 0);
})();
